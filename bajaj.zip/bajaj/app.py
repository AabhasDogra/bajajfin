from flask import Flask, request, jsonify
import string
import random

app = Flask(__name__)

@app.route('/endpoint', methods=['GET', 'POST'])
def endpoint():
    if request.method == 'GET':
        # Generate a random operation code
        operation_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
        return jsonify({'operation_code': operation_code})
    
    elif request.method == 'POST':
        content = request.json
        response_data = {
            'status': 'success',
            'user_id': content.get('user_id'),
            'college_email_id': content.get('college_email_id'),
            'college_roll_number': content.get('college_roll_number'),
            'array_for_numbers': [i for i in range(10)],  # example array of numbers
            'array_for_alphabets': list(string.ascii_lowercase)  # example array of alphabets
        }
        return jsonify(response_data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
